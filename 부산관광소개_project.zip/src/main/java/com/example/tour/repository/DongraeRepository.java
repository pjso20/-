package com.example.tour.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.tour.model.Dongrae;

public interface DongraeRepository extends JpaRepository<Dongrae, Long> {

}
