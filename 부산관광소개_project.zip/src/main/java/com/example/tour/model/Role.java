package com.example.tour.model;

public enum Role {
    ROLE_USER, ROLE_MANAGER, ROLE_ADMIN
}
