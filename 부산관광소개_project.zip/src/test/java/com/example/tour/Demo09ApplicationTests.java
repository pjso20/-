package com.example.tour;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo09ApplicationTests {

	@Test
	void contextLoads() {
	}

}
